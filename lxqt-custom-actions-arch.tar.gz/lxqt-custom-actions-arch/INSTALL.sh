#!/bin/bash
sudo pacman -S libertinus-font libnotify mupdf-tools nodejs npm perl-rename poppler texlive unoconv xclip --needed
paru -S graphicsmagick-imagemagick-compat pandoc-bin python-grip wkhtmltopdf-static
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/pandoc ]; then
  mkdir -p ~/.local/share/pandoc
fi
if [ ! -d $HOME/.local/share/file-manager/actions ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
rm ~/.local/share/file-manager/actions/*
cp actions/* ~/.local/share/file-manager/actions/
rm ~/.local/bin/*
cp bin/* ~/.local/bin/
rm -r ~/.local/share/pandoc/*
cp -r pandoc/* ~/.local/share/pandoc/
exit 0
