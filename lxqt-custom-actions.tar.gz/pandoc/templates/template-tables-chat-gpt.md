---
header-includes:
  - \usepackage{booktabs}
  - \usepackage{longtable}
---

$if(titleblock)$
$else$
\maketitle
$endif$

\tableofcontents

$if(tables)$
\listoftables
$endif$

$if(figures)$
\listoffigures
$endif$

$body$

$if(tables)$
$for(tables)$
\begin{longtable}[]{@{}lllll@{}}
\toprule
$if(firstrow)$
$for(firstrow)$
\textbf{$firstrow$} & 
$endfor$ 
\\ \midrule
$endif$
$if(headings)$
$for(headings)$
\textbf{$headings$} & 
$endfor$ 
\\ \midrule
$endif$
$for(rows)$
$for(row)$
$row$ & 
$endfor$ 
\\
$endfor$
\bottomrule
\end{longtable}
$endfor$
$endif$

### You can copy the entire code into a new file named template.tex. Here is a brief explanation of each section of the code:

    ---: This marks the beginning of the YAML metadata block in the template file.
    header-includes: This is a YAML field that specifies additional LaTeX packages to include in the Pandoc output. In this case, we are including the booktabs and longtable packages to format tables.
    $if(titleblock)$ and $else$: These lines check if the document has a title block. If it does, the template will skip over the title block and proceed to the table of contents. If it does not, the template will generate a default title block using the information specified in the YAML metadata block.
    \tableofcontents: This generates a table of contents for the Pandoc output.
    $if(tables)$ and $endif$: These lines check if the Markdown input contains any tables. If it does, the template will loop through the tables and generate LaTeX code to create each one. If there are no tables in the Markdown input, this section will be skipped.
    $for(tables)$ and $endfor$: These lines mark the beginning and end of the loop that generates LaTeX code for each table in the Markdown input.
    \begin{longtable} and \end{longtable}: This creates a longtable environment in LaTeX, which allows tables to span multiple pages if necessary. The \toprule, \midrule, and \bottomrule commands create horizontal lines to separate the table header, table body, and table footer, respectively.
    $if(firstrow)$ and $endif$: This checks if the table has a first row of data that should be formatted differently from the rest of the table. If it does, the template will generate LaTeX code to format that row.
    $for(firstrow)$ and $endfor$: This marks the beginning and end of the loop that generates LaTeX code for the first row of data in the table.
    $if(headings)$ and $endif$: This checks if the table has column headings that should be formatted differently from the rest of the table. If it does, the template will generate LaTeX code to format those headings.
    $for(headings)$ and $endfor$: This marks the beginning and end of the loop that generates LaTeX code for the column headings in the table.
    $for(rows)$ and $endfor$: This marks the beginning and end of the loop that generates LaTeX code for the table rows. Each row is generated using a nested loop that iterates over the data in each cell.

### standard default Pandoc default.latex template to include the code for bordered tables with bold headers

```latex
\documentclass[12pt,english]{article}
\usepackage{geometry}
\geometry{verbose,letterpaper,lmargin=2cm,rmargin=2cm}
\usepackage[utf8]{inputenc}
\usepackage{babel}

% Add packages for tables with borders and bold headings
\usepackage{booktabs}
\usepackage{longtable}

\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage{hyperref}
\hypersetup{
    colorlinks=true,
    linkcolor=blue,
    filecolor=blue,
    urlcolor=blue,
}

\title{$title$}
\author{$for(author)$$author$$sep$ \\ $endfor$}
\date{$date$}

\begin{document}
\maketitle
$if(toc)$
{
\hypersetup{linkcolor=black}
\setcounter{tocdepth}{$toc-depth$}
\tableofcontents
}
$endif$
$body$

$if(tables)$
$for(tables)$
% Add code for bordered tables with bold headers
\begin{longtable}[]{@{} $table.alignment$ @{}}
\toprule
$if(table.caption)$
\caption{$table.caption$}\\
\midrule
\endfirsthead
\multicolumn{1}{@{}l}{\ldots continued from previous page} \\
\midrule
\endhead
\midrule
\multicolumn{1}{@{}r}{\ldots continued on next page} \\
\endfoot
\bottomrule
\endlastfoot
$else$
\midrule
\endhead
\midrule
\multicolumn{1}{@{}r}{\ldots continued on next page} \\
\endfoot
\bottomrule
\endlastfoot
$endif$
$if(table.header)$
\textbf{$table.header$} \\
\midrule
\endhead
$endif$
$for(table.rows)$
$for(table.columns)$
$table.columns$ & 
$endfor$ \\
\midrule
$endfor$
\end{longtable}
$endfor$
$endif$

\end{document}
```

### Pandoc template for converting Markdown to a Beamer PDF with tables formatted with borders and bold headings

```latex
% !TeX program = xelatex
% !TeX encoding = UTF-8
\documentclass{beamer}
\usetheme{metropolis}
\usepackage{booktabs}
\usepackage{longtable}
\usepackage{array}

\begin{document}

\begin{frame}[fragile]
\frametitle{$title$}
$body$
\end{frame}

$if(tables)$
$for(tables)$
\begin{frame}[fragile]
\frametitle{$tables.title$}

\begin{longtable}{@{} $tables.alignment$ @{}}
\toprule
$if(tables.firstrow)$
$for(tables.firstrow)$
\textbf{$tables.firstrow$} &
$endfor$ \\
\midrule
$endif$
$if(tables.headings)$
$for(tables.headings)$
\textbf{$tables.headings$} &
$endfor$ \\
\midrule
$endif$
\endhead

$for(tables.rows)$
$for(tables.columns)$
$tables.columns$ &
$endfor$ \\
\midrule
$endfor$

\bottomrule
\end{longtable}

\end{frame}
$endfor$
$endif$

\end{document}
```
